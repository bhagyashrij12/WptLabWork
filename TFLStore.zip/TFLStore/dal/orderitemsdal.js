var sql = require("./mysqlconnect");

var OrderItem = function (OrderItem) {
  this.orderitemid = OrderItem.orderitemid;
  this.orderid = OrderItem.orderid;
  this.customerid = OrderItem.customerid;
  this.quantity = OrderItem.quantity;
};
OrderItem.createOrderItem = function (newOrderItem, result) {
  console.log("New OrderItem to be added ");
  console.log(newOrderItem);
  sql.query("INSERT INTO orderitems SET ?", newOrderItem, function (err, res) {
    if (err) {
      console.log("error: ", err);
      result(err, null);
    } else {
      console.log(res.insertId);
      result(null, res.insertId);
    }
  });
};

OrderItem.getOrderItemById = function (OrderItemId, result) {
  sql.query(
    "SELECT * FROM orderitems WHERE orderitemid = ? ",
    OrderItemId,
    function (err, res) {
      if (err) {
        console.log("error: ", err);
        result(err, null);
      } else {
        result(null, res);
      }
    }
  );
};

OrderItem.getAllOrderItem = function (result) {
  console.log("Invoking dal getall OrderItems");

  sql.query("SELECT * FROM orderitems", function (err, res) {
    if (err) {
      console.log("error: ", err);
      result(null, err);
    } else {
      console.log("OrderItems : ", res);
      result(null, res);
    }
  });
};



OrderItem.remove = function (id, pid, result) {
  sql.query(
    "DELETE FROM orderitems WHERE orderitemid = ? ",
    [id],
    function (err, res) {
      if (err) {
        console.log("error: ", err);
        result(null, err);
      } else {
        result(null, res);
      }
    }
  );
};

module.exports = OrderItem;
