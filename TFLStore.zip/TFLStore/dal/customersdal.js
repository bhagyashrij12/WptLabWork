var sql = require("./mysqlconnect");

var Customer = function (Customer) {
  this.id=Customer.id;
  this.firstname = Customer.firstname;
  this.lastname = Customer.lastname;
  this.email=Customer.email;
  this.contact=Customer.contact;
  
};
Customer.createCustomer = function (newCustomer, result) {
  console.log("New Customer to be added ");
  console.log(newCustomer);
  sql.query("INSERT INTO customer SET ?", newCustomer, function (err, res) {
    if (err) {
      console.log("error: ", err);
      result(err, null);
    } else {
      console.log(res.insertId);
      result(null, res.insertId);
    }
  });
};

Customer.getCustomerById = function (CustomerId, result) {
  sql.query(
    "SELECT * FROM customers WHERE id = ? ",
    CustomerId,
    function (err, res) {
      if (err) {
        console.log("error: ", err);
        result(err, null);
      } else {
        result(null, res);
      }
    }
  );
};

Customer.getAllCustomer = function (result) {
  console.log("Invoking dal getall Customers");

  sql.query("SELECT * FROM customer", function (err, res) {
    if (err) {
      console.log("error: ", err);
      result(null, err);
    } else {
      console.log("Customers : ", res);
      result(null, res);
    }
  });
};

Customer.updateById = function (id, Customer, result) {
  sql.query(
    "UPDATE customers SET firstname = ?,lastname = ?, email= ? ,contact=?  WHERE id = ?",
    [
      Customer.firstname,
      Customer.lastname,
      Customer.email,
      Customer.contact,
      
      id,
    ],
    function (err, res) {
      if (err) {
        console.log("error: ", err);
        result(null, err);
      } else {
        result(null, res);
      }
    }
  );
};

Customer.remove = function (id, result) {
  sql.query(
    "DELETE FROM customer WHERE id = ?",
    id,
    function (err, res) {
      if (err) {
        console.log("error: ", err);
        result(null, err);
      } else {
        result(null, res);
      }
    }
  );
};

module.exports = Customer;
