//a Separate responsibility  for  Flowers  HTTP request handling

var OrderItem = require("../dal/orderitemsdal");

exports.getAll = function (req, res) {
  console.log("calling controller function");
  OrderItem.getAllOrderItem(function (err, orderItem) {
    if (err) res.send(err);
    res.send(orderItem);
  });
};

exports.insert = function (req, res) {
  var new_OI = new OrderItem(req.body);
  console.log(new_OI);

  //handles null error
  
    OrderItem.createOrderItem(new_OI, function (err, orderItem) {
      if (err) res.send(err);
      res.json(orderItem);
    });
 
};

exports.getBy = function (req, res) {
  Flower.getFlowerById(req.params.id, function (err, flower) {
    if (err) res.send(err);
    res.json(flower);
  });
};



exports.remove = function (req, res) {
  OrderItem.remove(req.params.id, function (err, orderItem) {
    if (err) res.send(err);
    res.json({ message: "order  deleted" });
  });
};
